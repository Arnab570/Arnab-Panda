from tkinter import *

root = Tk()
root.geometry('300x300')
root.title("Melody")
root.iconbitmap(r'melody.ico')

root.mainloop()